import { Bot, InlineKeyboard, webhookCallback } from "grammy";
import type { DbClient } from "../db/client";
import * as db from "../db/queries";

export function createAdminBot(env: { ADMIN_BOT_TOKEN: string; ADMIN_ID: string }, dbClient: DbClient) {
  const bot = new Bot(env.ADMIN_BOT_TOKEN);

  // Admin only
  bot.use(async (ctx, next) => {
    if (String(ctx.from?.id) !== env.ADMIN_ID) {
      await ctx.reply("⛔ Доступ запрещен");
      return;
    }
    await next();
  });

  bot.command("start", async (ctx) => {
    const kb = new InlineKeyboard()
      .row(
        InlineKeyboard.text("📊 Статистика", "stats"),
        InlineKeyboard.text("👥 Пользователи", "users")
      )
      .row(
        InlineKeyboard.text("🔑 Ключи", "keys"),
        InlineKeyboard.text("📢 Рассылка", "broadcast")
      )
      .row(
        InlineKeyboard.text("💬 Поддержка", "support"),
        InlineKeyboard.text("📤 Экспорт", "export")
      );

    await ctx.reply(
      "🔐 Панель администратора\n\n" +
      "Выберите действие:",
      { reply_markup: kb }
    );
  });

  // Stats
  bot.callbackQuery("stats", async (ctx) => {
    const allUsers = await db.getAllUsers(dbClient);
    const activeUsers = await db.getActiveUsers(dbClient);
    
    const text = 
      "📊 Статистика:\n\n" +
      `👥 Всего: ${allUsers.length}\n` +
      `✅ Активных: ${activeUsers.length}\n` +
      `🚫 Забаненных: ${allUsers.length - activeUsers.length}`;

    const kb = new InlineKeyboard().text("⬅️ Назад", "start");
    await ctx.editMessageText(text, { reply_markup: kb });
    await ctx.answerCallbackQuery();
  });

  // Users
  bot.callbackQuery("users", async (ctx) => {
    const users = await db.getAllUsers(dbClient);
    
    let text = "👥 Список пользователей:\n\n";
    users.slice(0, 10).forEach((user, i) => {
      text += `${i + 1}. ${user.name}${user.banned ? ' 🚫' : ''}\n`;
    });
    if (users.length > 10) {
      text += `\n...и еще ${users.length - 10} пользователей`;
    }

    const kb = new InlineKeyboard()
      .text("⬅️ Назад", "start");

    await ctx.editMessageText(text, { reply_markup: kb });
    await ctx.answerCallbackQuery();
  });

  // Keys
  bot.callbackQuery("keys", async (ctx) => {
    const freeKey = await db.getFreeKey(dbClient);
    const premiumKey = await db.getAvailablePremiumKey(dbClient);
    
    const text = 
      "🔑 Управление ключами\n\n" +
      `🎫 Бесплатных ключей: ${freeKey ? 1 : 0}\n` +
      `💎 Премиум ключей: ${premiumKey ? 1 : 0}\n\n` +
      "Команды:\n" +
      "/addfree <ключ> - добавить бесплатный\n" +
      "/addpremium <ключ> - добавить премиум";

    const kb = new InlineKeyboard().text("⬅️ Назад", "start");
    await ctx.editMessageText(text, { reply_markup: kb });
    await ctx.answerCallbackQuery();
  });

  // Add free key
  bot.command("addfree", async (ctx) => {
    const key = ctx.message?.text?.split(' ')[1];
    if (!key) {
      await ctx.reply("⚠️ Используйте: /addfree <ключ>");
      return;
    }
    
    await db.addFreeKey(dbClient, key);
    await ctx.reply(`✅ Бесплатный ключ добавлен: ${key}`);
  });

  // Add premium key
  bot.command("addpremium", async (ctx) => {
    const key = ctx.message?.text?.split(' ')[1];
    if (!key) {
      await ctx.reply("⚠️ Используйте: /addpremium <ключ>");
      return;
    }
    
    await db.addPremiumKey(dbClient, key);
    await ctx.reply(`✅ Премиум ключ добавлен: ${key}`);
  });

  // Broadcast
  bot.callbackQuery("broadcast", async (ctx) => {
    const text = 
      "📢 Рассылка\n\n" +
      "Используйте команду:\n" +
      "/broadcast <текст сообщения>";

    const kb = new InlineKeyboard().text("⬅️ Назад", "start");
    await ctx.editMessageText(text, { reply_markup: kb });
    await ctx.answerCallbackQuery();
  });

  bot.command("broadcast", async (ctx) => {
    const message = ctx.message?.text?.replace('/broadcast', '').trim();
    if (!message) {
      await ctx.reply("⚠️ Используйте: /broadcast <текст>");
      return;
    }

    const users = await db.getAllUsers(dbClient);
    let sent = 0;
    let failed = 0;

    for (const user of users) {
      if (user.banned) continue;
      try {
        await bot.api.sendMessage(parseInt(user.telegramId), message);
        sent++;
      } catch (error) {
        failed++;
      }
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    await ctx.reply(
      `✅ Рассылка завершена!\n` +
      `📨 Отправлено: ${sent}\n` +
      `❌ Ошибок: ${failed}`
    );
  });

  // Support
  bot.callbackQuery("support", async (ctx) => {
    const text = 
      "💬 Поддержка\n\n" +
      "Команды:\n" +
      "/reply <user_id> <текст> - ответить пользователю";

    const kb = new InlineKeyboard().text("⬅️ Назад", "start");
    await ctx.editMessageText(text, { reply_markup: kb });
    await ctx.answerCallbackQuery();
  });

  bot.command("reply", async (ctx) => {
    const parts = ctx.message?.text?.split(' ');
    if (!parts || parts.length < 3) {
      await ctx.reply("⚠️ Используйте: /reply <user_id> <текст>");
      return;
    }

    const userId = parseInt(parts[1]);
    const message = parts.slice(2).join(' ');
    
    try {
      await bot.api.sendMessage(userId, `🤖 Ответ поддержки:\n\n${message}`);
      await ctx.reply(`✅ Ответ отправлен пользователю ${userId}`);
    } catch (error) {
      await ctx.reply(`❌ Ошибка: ${error}`);
    }
  });

  // Export
  bot.callbackQuery("export", async (ctx) => {
    const users = await db.getAllUsers(dbClient);
    
    let csv = "ID,Имя,Username,Забанен,Создан\n";
    users.forEach(user => {
      csv += `${user.telegramId},"${user.name}","${user.username}",${user.banned},${new Date(user.createdAt).toISOString()}\n`;
    });

    await ctx.reply("📤 Экспорт пользователей:");
    await ctx.reply(`\`\`\`\n${csv}\n\`\`\``, { parse_mode: "Markdown" });
    await ctx.answerCallbackQuery();
  });

  // Back to start
  bot.callbackQuery("start", async (ctx) => {
    const kb = new InlineKeyboard()
      .row(
        InlineKeyboard.text("📊 Статистика", "stats"),
        InlineKeyboard.text("👥 Пользователи", "users")
      )
      .row(
        InlineKeyboard.text("🔑 Ключи", "keys"),
        InlineKeyboard.text("📢 Рассылка", "broadcast")
      )
      .row(
        InlineKeyboard.text("💬 Поддержка", "support"),
        InlineKeyboard.text("📤 Экспорт", "export")
      );

    await ctx.editMessageText(
      "🔐 Панель администратора\n\n" +
      "Выберите действие:",
      { reply_markup: kb }
    );
    await ctx.answerCallbackQuery();
  });

  return bot;
}

export function adminBotWebhookHandler(env: any, db: DbClient) {
  const bot = createAdminBot(env, db);
  return webhookCallback(bot, "cloudflare-mod");
}
